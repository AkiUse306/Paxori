﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PaxoriApp.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

