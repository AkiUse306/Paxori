# Paxori

Paxori is a modern, cross-platform file transfer experience designed to make sharing files between devices feel simple, fast, and secure.

## What it includes
- a polished landing experience for the product vision
- a transfer studio preview for selecting and simulating transfers
- colorful installer scripts for a more native-feeling setup

## Run locally

### With Node
```bash
npm start
```

Then open http://127.0.0.1:3000

## Install

### Linux / macOS
User install (default):
```bash
bash install.sh
```
System-wide install:
```bash
sudo bash install.sh --global
```

### Windows (PowerShell)
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://raw.githubusercontent.com/AkiUse306/Paxori/main/install.ps1 | iex"
```

### Windows (Command Prompt)
User install:
```bat
install.bat
```
System-wide install:
```bat
install.bat --global
```

## Philosophy
Paxori is built around three principles:
- Simple
- Fast
- Reliable
